Οδηγίες φιλοξενίας της σελίδας Paduce (σύντομες)

1) GitHub Pages (δωρεάν)
- Δημιούργησε ένα νέο repository στο GitHub (π.χ. paduce-story).
- Πρόσθεσε το αρχείο paduce.html στο repository.
- Στις ρυθμίσεις (Settings) -> Pages, επίλεξε το branch main και το folder / (root).
- Μετά από λίγα λεπτά, η σελίδα θα είναι διαθέσιμη στο https://<username>.github.io/paduce-story/paduce.html

2) Netlify (εύκολο drag & drop)
- Άνοιξε netlify.com και δημιούργησε λογαριασμό.
- Στο Dashboard, επίλεξε "Add new site" → "Deploy manually".
- Σύρε και άφησε το αρχείο paduce.html στο πλαίσιο.
- Η σελίδα θα αποκτήσει προσωρινό URL που μπορείς να αλλάξεις με δικό σου domain.

3) Τοπικά / γρήγορο preview
- Άνοιξε το paduce.html με διπλό κλικ στο browser σου (file:///...).
- Για τοπικό web server: python3 -m http.server 8000 και άνοιξε http://localhost:8000/paduce.html

Αν θες, μπορώ να δημιουργήσω επίσης ένα αρχείο ZIP με το HTML ή να παράγω ένα README σε μορφή markdown. Πες μου τι προτιμάς.
